#!/usr/bin/env python3

import sys
import string
import re
import csv

import logging
import logging.config


import fire
import dateparser
import tablib
from pyexcel.internal.generators import SheetStream
from pyexcel.plugins.sources.file_output import WriteSheetToFile
# import pyexcel as pe
# import pyexcel_xlsx
from loguru import logger

RESULT_HEADER = 'text	subtext	entity	training	vacation'.split()

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', 
                    level=logging.DEBUG)
csv.field_size_limit(sys.maxsize)

def main(inputfile, outputfile, *fieldnames):
    assert fieldnames
    assert outputfile.endswith('.xlsx')
    
    with open('data/symptomList') as fsy:
        symptom_pattern = re.compile("({})".format('|'.join(re.escape(line.strip()) 
                                                            for line in fsy)))
        #sorted((line.strip() for line in fsy), key=len, reverse=True)
    with open('data/diagnosisList') as fdx:
        diagnosis_pattern = re.compile("({})".format('|'.join(re.escape(line.strip()) 
                                                              for line in fdx)))
        #sorted((line.strip() for line in fdx), key=len, reverse=True)

    # data = tablib.Dataset()
    # data.header = RESULT_HEADER

    with open(inputfile) as fin:
        reader = csv.DictReader(fin) #, fieldnames)
        row_gen = annotate(reader, symptom_pattern, diagnosis_pattern, fieldnames)
        # for row in row_gen:
        #     data.append(row)
        
        ws = WriteSheetToFile(outputfile)
        sheet_stream = SheetStream("train", row_gen)
        ws.write_data(sheet_stream)

    # with open(outputfile, 'wb') as fout:
    #     fout.write(data.xlsx)
    
    
def annotate(input, symptom_pattern, diagnosis_pattern, fieldnames):
    yield RESULT_HEADER
    for i, row in enumerate(input):
        if i == 0:
            header = list(row.keys())
            header.insert(0, 'trng_vaca')
        
        training = False
        vacation = False
        for fname in fieldnames:
            text = row[fname].strip()
            if not text:
                continue
            logger.info(f'{i} :{text}')
            tokens = text.split()
            
            onset_dates = []
            for token in tokens:
                if all(c in string.punctuation for c in token):
                    continue
                try:
                    if dateparser.parse(token, languages=['ko', 'ja', 'zh', 'en'], 
                                        settings={'PREFER_DATES_FROM': 'past',
                                                  'STRICT_PARSING': True,
                                                  'SKIP_TOKENS': list('#()')}) is not None:
                        onset_dates.append(token)
                except ValueError:
                    pass
            
            symptoms = [match.group(0) for match in symptom_pattern.finditer(text)]
            diagnosis = [match.group(0) for match in diagnosis_pattern.finditer(text)]
            training = training or ('훈련' in text)
            vacation = vacation or ('휴가' in text)
            
            yield [text, '', '', int(training), int(vacation)]

            for sy in symptoms:
                yield ['', sy, 'SY', '', '']      
            
            for dx in diagnosis:
                yield ['', dx, 'DX', '', '']
                
            for odt in onset_dates:
                yield ['', odt, 'ODT', '', '']
              
if __name__ == "__main__":
    fire.Fire(main)