#!/usr/bin/env python3

import sys
import csv
import uuid
import re
# from itertools import chain

import fire
import dateparser
from loguru import logger

csv.field_size_limit(sys.maxsize)

def or_pattern(entities):
    # logger.info(entities)
    result = '(' + format('|'.join(re.escape(ent) for ent in entities if len(ent) > 1)) + ')'
    logger.info(result)
    return result
    
def tag_entities(text, entities, tag):
    pattern = or_pattern(entities) 
    return re.sub(pattern, r'<{0}>\1</{0}>'.format(tag), text) if entities and len(pattern) > 3 else text

def main(inputfile, outputfile, tablename, *fieldnames):
    with open('data/symptomList') as fsy:
        symptom_list = list((line.strip() for line in fsy)) #sorted((line.strip() for line in fsy), key=len, reverse=True)
    with open('data/diagnosisList') as fdx:
        diagnosis_list = list((line.strip() for line in fdx)) #sorted((line.strip() for line in fdx), key=len, reverse=True)
    with open(inputfile) as fin, open(outputfile, 'wt') as fout:
        reader = csv.DictReader(fin) #, fieldnames)
        
        for i, row in enumerate(reader):
            if i == 0:
                header = list(row.keys())
                header.insert(0, 'trng_vaca')
                writer = csv.DictWriter(fout, header)   
                writer.writeheader()
            wrow = row.copy()
            training = False
            vacation = False
            for fname in fieldnames:
                text = row[fname]
                tokens = text.split()
                
                onset_dates = []
                for token in tokens:
                    try:
                        if dateparser.parse(token, languages=['ko', 'ja', 'zh', 'en']) is not None:
                            onset_dates.append(token)
                    except ValueError:
                        pass
                
                symptoms = [sy for sy in symptom_list if sy in text]
                diagnosis = [dx for dx in diagnosis_list if dx in text]
                # breakpoint()
                training = training or ('훈련' in text)
                vacation = vacation or ('휴가' in text)
                
                if onset_dates:
                    text = tag_entities(text, onset_dates, 'odt')
                if symptoms:
                    text = tag_entities(text, symptoms, 'sy')
                if diagnosis:
                    text = tag_entities(text, diagnosis, 'dx')
                wrow[fname] = text
            
            wrow['trng_vaca'] = ('trng' if training else 'vaca' if vacation else '')
            logger.info(wrow)
            writer.writerow(wrow)


if __name__ == "__main__":
    fire.Fire(main)