#!/usr/bin/env python3

import sys
import csv
import uuid
import re
# from itertools import chain

import fire
import dateparser
# import pyexcel as pe
# import pyexcel_xlsx
from loguru import logger

csv.field_size_limit(sys.maxsize)

data_path = 'data/train_data.xlsx'

def excel():
    excelcy = ExcelCy()
    excelcy.storage.base_path = data_path
    excelcy.storage.config = Config(nlp_base='en_core_web_sm', train_iteration=2, train_drop=0.2)
    excelcy.storage.source.add(kind='text', value=text_value)
    excelcy.storage.prepare.add(kind='phrase', value=value, entity=entity)

def main(inputfile, outputfile, *fieldnames):
    # def render_row(rows):
    #     # for row in rows:
    #     yield from rows
    
    with open('data/symptomList') as fsy:
        symptom_list = list((line.strip() for line in fsy)) #sorted((line.strip() for line in fsy), key=len, reverse=True)
    with open('data/diagnosisList') as fdx:
        diagnosis_list = list((line.strip() for line in fdx)) #sorted((line.strip() for line in fdx), key=len, reverse=True)

    with open(inputfile) as fin:
        reader = csv.DictReader(fin) #, fieldnames)
        rows_gen = annotate(reader, symptom_list, diagnosis_list, fieldnames)   
        breakpoint()
        pe.isave_as(file_name="data/train_data_template.xlsx", dest_file_name=outputfile,
                    sheet_name='train', dest_sheet_name='train',
                    dest_content=rows_gen) #, row_renderer=render_row)
    
    pe.free_resources()
    
    
def annotate(input, symptom_list, diagnosis_list, fieldnames):
    yield 'text	subtext	entity	training	vacation'.split()
    
    for i, row in enumerate(input):
        if i == 0:
            header = list(row.keys())
            header.insert(0, 'trng_vaca')
        
        training = False
        vacation = False
        for fname in fieldnames:
            text = row[fname]                
            logger.info(text)
            tokens = text.split()
            
            onset_dates = []
            for token in tokens:
                try:
                    if dateparser.parse(token, languages=['ko', 'ja', 'zh', 'en']) is not None:
                        onset_dates.append(token)
                except ValueError:
                    pass
            
            symptoms = [sy for sy in symptom_list if sy in text]
            diagnosis = [dx for dx in diagnosis_list if dx in text]
            training = training or ('훈련' in text)
            vacation = vacation or ('휴가' in text)
            
            yield [text, '', '', int(training), int(vacation)]

            for sy in symptoms:
                yield ['', sy, 'SY']      
            
            for dx in diagnosis:
                yield ['', dx, 'DX']
                
            for odt in onset_dates:
                yield ['', odt, 'ODT']
              
if __name__ == "__main__":
    fire.Fire(main)