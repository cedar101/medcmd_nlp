#!/usr/bin/env python3

import sys
import csv
import uuid
import string

import fire
import dateparser
from loguru import logger


mined_field_header = """id	table_name	field_name	patient_id	enlist_date	discharge_date	birthday	training	vacation	onset_dates	symptoms	diagnosis""".split()

csv.field_size_limit(sys.maxsize)

def main(inputfile, outputfile, tablename, *fieldnames):
    with open('data/symptomList') as fsy:
        symptom_list = sorted((line.strip() for line in fsy), key=len, reverse=True)
    with open('data/diagnosisList') as fdx:
        diagnosis_list = sorted((line.strip() for line in fdx), key=len, reverse=True)
    with open(inputfile) as fin, open(outputfile, 'wt') as fout:
        reader = csv.DictReader(fin) #, fieldnames)
        writer = csv.DictWriter(fout, mined_field_header, dialect=csv.excel_tab)   
        writer.writeheader()
        for row in reader:
            for fname in fieldnames:
                text = row[fname]
                tokens = text.split()
                
                onset_dates = []
                for token in tokens:
                    if all(c in string.punctuation for c in token):
                        continue
                    onset_dt = None
                    try:
                        onset_dt = dateparser.parse(token, languages=['ko', 'ja', 'zh', 'en'],
                                                    settings={'PREFER_DATES_FROM': 'past',
                                                              'STRICT_PARSING': True,
                                                              'SKIP_TOKENS': list('#()')})
                    except ValueError:
                        continue
                    if onset_dt is not None:
                        logger.info(onset_dt)
                        onset_dates.append(onset_dt.date().isoformat() if token[0].isnumeric() else token)
                    

                symptoms = [sy for sy in symptom_list if sy in text]
                diagnosis = [dx for dx in diagnosis_list if dx in text]
                mined_row = {
                    'id': str(uuid.uuid4()), 
                    'table_name': tablename, 'field_name': fname,
                    'patient_id': row['PTNTNO'], 
                    'training': int('훈련' in text),
                    'vacation': int('휴가' in text),
                    'onset_dates': ','.join(onset_dates),
                    'symptoms': ','.join(symptoms),
                    'diagnosis': ','.join(diagnosis),
                }
                logger.info(mined_row)
                writer.writerow(mined_row)


if __name__ == "__main__":
    fire.Fire(main)