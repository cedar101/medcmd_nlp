import sys
import random

from loguru import logger
import spacy
from excelcy import ExcelCy                                                                                                                                          
from excelcy.utils import odict

class ErrorSkippingExcelCy(ExcelCy):
    def create_nlp(self):
        nlp = spacy.blank("en") 
        return nlp
    
    @logger.catch
    def train(self):
        nlp = self.nlp

        # gather unique entities
        logger.info('gather unique entities')
        entities = []
        for _, train in self.storage.train.items.items():
            for _, gold in train.items.items():
                entities.append(gold.entity)

        # add custom entities based on https://spacy.io/usage/training#example-new-entity-type
        logger.info('add custom entities')
        # ner = nlp.get_pipe('ner')
        ner = nlp.create_pipe("ner")
        nlp.add_pipe(ner, last=True)
        for entity in set(entities):
            if entity:
                ner.add_label(entity)

        # prepare data
        logger.info('prepare data')
        train_idx = list(self.storage.train.items.keys())
        trains = odict()
        for idx, train in self.storage.train.items.items():
            entities = odict()
            for gold_idx, gold in train.items.items():
                # ensure offset is valid positions
                logger.info(f'gold: {gold}')
                if not gold.offset and gold.subtext:
                    offset = train.text.find(gold.subtext)
                    if offset != -1:
                        gold.offset = '%s,%s' % (offset, offset + len(gold.subtext))
                if gold.offset is not None:
                    offset = gold.offset.replace(' ', '').strip()
                if not entities.get(offset):
                    entities[offset] = gold.entity
            trains[idx] = {'entities': []}
            for offset, entity in entities.items():
                if not isinstance(offset, str):
                    continue
                offsets = offset.split(',')
                trains[idx]['entities'].append([int(offsets[0]), int(offsets[1]), entity])

        # train now
        logger.info('train now')
        nlp.vocab.vectors.name = 'spacy_pretrained_vectors'
        optimizer = nlp.begin_training()
        for itn in range(self.storage.config.train_iteration):
            random.shuffle(train_idx)
            for idx in train_idx:
                text = self.storage.train.items[idx].text
                train = trains[idx]
                nlp.update([text], [train], drop=self.storage.config.train_drop, sgd=optimizer)

        return self


def main():
    excelcy = ErrorSkippingExcelCy.execute(file_path=sys.argv[1])
    logger.info('save the model')
    excelcy.nlp.to_disk('./model')

if __name__ == "__main__":
    main() 