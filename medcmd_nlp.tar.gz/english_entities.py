import spacy
from scispacy.candidate_generation import CandidateGenerator
from scispacy.umls_utils import UmlsKnowledgeBase
from scispacy.umls_linking import UmlsEntityLinker

DISEASE_TYPES = ['T046', 'T047', 'T048']
SYMPTOM_TYPE = 'T184'

def main():
    candgen = CandidateGenerator(umls=UmlsKnowledgeBase(file_path='data/umls_2017_aa_cat0129.json'))
    linker = UmlsEntityLinker(candgen)
    nlp = spacy.load("en_core_sci_sm")
    nlp.add_pipe(linker)

    doc = nlp("Spinal and bulbar muscular atrophy (SBMA) is an \
inherited motor neuron disease caused by the expansion \
of a polyglutamine tract within the androgen receptor (AR). \
SBMA can be caused by this easily.")
    
    for entity in doc.ents:
        for umls_ent in entity._.umls_ents:
            ent = linker.umls.cui_to_entity[umls_ent[0]]
            if ent.type in DISEASE_TYPES:
                print(ent.canonical_name)


if __name__ == '__main__':
    main() 