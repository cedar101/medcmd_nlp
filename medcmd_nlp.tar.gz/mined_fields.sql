CREATE TABLE IF NOT EXISTS mined_fields (
    id STRING, -- PRIMARY KEY(id) DISABLE NOVALIDATE
    table_name STRING, -- 추출한 테이블 이름
    field_name STRING, -- 추출한 필드 이름
    patient_id STRING, -- 환자번호(PTNT_NO)
    enlist_date DATE, -- 입대 일자
    discharge_date DATE, -- 전역 일자
    birthday DATE, -- 생년월일
    training BOOLEAN, -- 훈련상황 여부
    vacation BOOLEAN, -- 휴가 시 발생 여부
    onset_dates ARRAY<STRING>, -- 발병일자
    symptoms ARRAY<STRING>, -- 증상
    diagnosis ARRAY<STRING> -- 진단명
) 
ROW FORMAT DELIMITED -- SERDE 'org.apache.hive.hcatalog.data.JsonSerDe'
    FIELDS TERMINATED BY '\t'
    COLLECTION ITEMS TERMINATED BY ','
STORED AS TEXTFILE; 

insert into mined_fields
select '496b49c5-493a-4a2a-aecb-ec06cb9d7cfa', 'THME_DCHGHSPT_SMRY_RCDPPR', 'IHSPTLZ_RSN', 'I594f26cb3f08c2d91a4ccb6b61a58d5a268c396140f45379f554e5a52fbd26c4',
null,null,null,0,0,array('13/12/18','2018/3/5'),array('통증','부종'),array('gout')